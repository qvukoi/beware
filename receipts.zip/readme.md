**receipts_0.py**: creates Data.xlsx; an empty sheet named "data"; columns "name", "weight", "price". Can be used to reset Data.xlsx.
**receipts.py**: the main script. Asks "name", "weight", "price" continually and saves user's answers to Data.xlsx; before closing, displays a total of the whole "price" column.

uses pandas, openpyxl